<?php
include '../../config/database.php';

if (isset($_POST['productId'])) {
    $productId = intval($_POST['productId']);
    
    try {
        // Get basic product information
        $stmt = $mainPdo->prepare("
            SELECT 
                p.productId,
                p.productName,
                p.description,
                p.productImage,
                p.categoryId,
                c.categoryName
            FROM products p
            LEFT JOIN categories c ON p.categoryId = c.categoryId
            WHERE p.productId = :productId
        ");
        
        $stmt->execute([':productId' => $productId]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$product) {
            echo json_encode(['error' => true, 'message' => 'Product not found']);
            exit;
        }
        
        // Get vendor prices from all vendor databases
        $vendorPricesQuery = "
            SELECT 
                vp.price,
                vp.productUrl,
                vp.lastUpdated,
                v.vendorId,
                v.vendorName
            FROM (
                SELECT productId, price, productUrl, lastUpdated, vendorId
                FROM vendor_1_prices.vendor_prices
                WHERE productId = :productId AND price > 0
                UNION ALL
                SELECT productId, price, productUrl, lastUpdated, vendorId
                FROM vendor_2_prices.vendor_prices
                WHERE productId = :productId AND price > 0
                UNION ALL
                SELECT productId, price, productUrl, lastUpdated, vendorId
                FROM vendor_3_prices.vendor_prices
                WHERE productId = :productId AND price > 0
                UNION ALL
                SELECT productId, price, productUrl, lastUpdated, vendorId
                FROM vendor_4_prices.vendor_prices
                WHERE productId = :productId AND price > 0
                UNION ALL
                SELECT productId, price, productUrl, lastUpdated, vendorId
                FROM vendor_5_prices.vendor_prices
                WHERE productId = :productId AND price > 0
            ) vp
            JOIN vendors v ON vp.vendorId = v.vendorId
            ORDER BY vp.price ASC
        ";
        
        $stmt = $mainPdo->prepare($vendorPricesQuery);
        $stmt->execute([':productId' => $productId]);
        $vendorPrices = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Add vendor prices to the product data
        $product['vendorPrices'] = $vendorPrices;
        
        // Return success response
        echo json_encode([
            'error' => false,
            'data' => $product
        ]);
        
    } catch (PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
        echo json_encode([
            'error' => true,
            'message' => 'Database error occurred'
        ]);
    } catch (Exception $e) {
        error_log("General Error: " . $e->getMessage());
        echo json_encode([
            'error' => true,
            'message' => 'An error occurred'
        ]);
    }
} else {
    echo json_encode([
        'error' => true,
        'message' => 'Product ID not provided'
    ]);
}