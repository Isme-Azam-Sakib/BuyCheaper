<?php
include '../config/database.php';

if (isset($_POST['query']) && !empty($_POST['query'])) {
    $search = "%" . $_POST['query'] . "%";
    
    $stmt = $mainPdo->prepare("
        SELECT DISTINCT
            p.productId, 
            p.productName AS name, 
            p.productImage AS image,
            p.description,
            MIN(vp.price) AS lowestPrice,
            v.vendorName,
            v.vendorLogo
        FROM products p
        LEFT JOIN (
            SELECT productId, price, vendorId
            FROM vendor_1_prices.vendor_prices
            WHERE price > 0
            UNION ALL
            SELECT productId, price, vendorId
            FROM vendor_2_prices.vendor_prices
            WHERE price > 0
            UNION ALL
            SELECT productId, price, vendorId
            FROM vendor_3_prices.vendor_prices
            WHERE price > 0
            UNION ALL
            SELECT productId, price, vendorId
            FROM vendor_4_prices.vendor_prices
            WHERE price > 0
            UNION ALL
            SELECT productId, price, vendorId
            FROM vendor_5_prices.vendor_prices
            WHERE price > 0
        ) vp ON p.productId = vp.productId
        LEFT JOIN vendors v ON vp.vendorId = v.vendorId
        WHERE p.productName LIKE :search
        GROUP BY p.productId, p.productName, p.productImage, p.description, v.vendorName, v.vendorLogo
        LIMIT 10
    ");
    
    $stmt->execute([':search' => $search]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($results) {
        header('Content-Type: application/json');
        echo json_encode($results);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['message' => 'No results found']);
    }
} else {
    echo json_encode(['message' => 'Invalid request']);
}
?>
