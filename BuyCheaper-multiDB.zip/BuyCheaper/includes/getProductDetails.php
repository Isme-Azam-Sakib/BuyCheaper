<?php
include '../config/database.php';

if (isset($_GET['productId'])) {
    $productId = intval($_GET['productId']);
    
    $stmt = $mainPdo->prepare("
        SELECT 
            p.productId,
            p.productName as name,
            p.productImage as image,
            p.description,
            MIN(vp.price) as lowest_price,
            v.vendorName as vendor_name,
            v.vendorLogo as vendor_logo,
            vp.productUrl as vendor_url
        FROM products p
        LEFT JOIN (
            SELECT productId, price, vendorId, productUrl
            FROM vendor_1_prices.vendor_prices
            WHERE price > 0
            UNION ALL
            SELECT productId, price, vendorId, productUrl
            FROM vendor_2_prices.vendor_prices
            WHERE price > 0
            UNION ALL
            SELECT productId, price, vendorId, productUrl
            FROM vendor_3_prices.vendor_prices
            WHERE price > 0
            UNION ALL
            SELECT productId, price, vendorId, productUrl
            FROM vendor_4_prices.vendor_prices
            WHERE price > 0
            UNION ALL
            SELECT productId, price, vendorId, productUrl
            FROM vendor_5_prices.vendor_prices
            WHERE price > 0
        ) vp ON p.productId = vp.productId
        LEFT JOIN vendors v ON vp.vendorId = v.vendorId
        WHERE p.productId = :productId
        GROUP BY p.productId, p.productName, p.productImage, p.description, 
                 v.vendorName, v.vendorLogo, vp.productUrl
    ");
    
    $stmt->execute([':productId' => $productId]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($product) {
        header('Content-Type: application/json');
        echo json_encode($product);
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Product not found']);
    }
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Product ID not provided']);
}
?>
