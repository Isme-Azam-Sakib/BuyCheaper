<?php
// Include the database configuration
include '../config/database.php';

if (isset($_GET['categoryId'])) {
    $categoryId = intval($_GET['categoryId']);

    $stmt = $mainPdo->prepare("
        SELECT 
            p.productId, 
            p.productName,
            MIN(vp.price) as price,
            v.vendorName,
            v.vendorLogo
        FROM products p
        JOIN (
            SELECT productId, price, vendorId
            FROM vendor_1_prices.vendor_prices
            WHERE price > 0
            UNION ALL
            SELECT productId, price, vendorId
            FROM vendor_2_prices.vendor_prices
            WHERE price > 0
            UNION ALL
            SELECT productId, price, vendorId
            FROM vendor_3_prices.vendor_prices
            WHERE price > 0
            UNION ALL
            SELECT productId, price, vendorId
            FROM vendor_4_prices.vendor_prices
            WHERE price > 0
            UNION ALL
            SELECT productId, price, vendorId
            FROM vendor_5_prices.vendor_prices
            WHERE price > 0
        ) vp ON p.productId = vp.productId
        JOIN vendors v ON vp.vendorId = v.vendorId
        WHERE p.categoryId = :categoryId
        GROUP BY p.productId, p.productName, v.vendorName, v.vendorLogo
        ORDER BY price ASC
    ");

    $stmt->execute([':categoryId' => $categoryId]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}
?>
