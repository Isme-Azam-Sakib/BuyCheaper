<?php
$mainDbConfig = [
    'host' => 'localhost',
    'dbname' => 'vendor_buycheaper_main',
    'user' => 'root',
    'pass' => ''
];

$vendorDbConfigs = [
    1 => ['dbname' => 'vendor_1_prices', 'vendor_name' => 'startech'],
    2 => ['dbname' => 'vendor_2_prices', 'vendor_name' => 'techland'],
    3 => ['dbname' => 'vendor_3_prices', 'vendor_name' => 'skyland'],
    4 => ['dbname' => 'vendor_4_prices', 'vendor_name' => 'ultratech'],
    5 => ['dbname' => 'vendor_5_prices', 'vendor_name' => 'pchouse']
];

try {
    $mainPdo = new PDO(
        "mysql:host={$mainDbConfig['host']};dbname={$mainDbConfig['dbname']}", 
        $mainDbConfig['user'], 
        $mainDbConfig['pass']
    );
    $mainPdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $mainPdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Main database connection failed: " . $e->getMessage());
}

// Create connections for vendor databases
$vendorConnections = [];
try {
    foreach ($vendorDbConfigs as $vendorId => $config) {
        $vendorConnections[$vendorId] = new PDO(
            "mysql:host={$mainDbConfig['host']};dbname={$config['dbname']}", 
            $mainDbConfig['user'], 
            $mainDbConfig['pass']
        );
        $vendorConnections[$vendorId]->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $vendorConnections[$vendorId]->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    die("Vendor database connection failed: " . $e->getMessage());
}


function getVendorConnection($vendorId) {
    global $vendorConnections;
    return isset($vendorConnections[$vendorId]) ? $vendorConnections[$vendorId] : null;
}

function getVendorName($vendorId) {
    global $vendorDbConfigs;
    return isset($vendorDbConfigs[$vendorId]) ? $vendorDbConfigs[$vendorId]['vendor_name'] : null;
}


$pdo = $mainPdo;
?>
